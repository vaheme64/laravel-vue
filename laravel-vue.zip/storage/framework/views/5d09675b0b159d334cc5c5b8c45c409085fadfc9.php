

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title">
                            <div class="d-flex align-item-center">
                                <h1><?php echo e($question->title); ?></h1>
                                <div class="ml-auto">
                                    <a href="<?php echo e(route('questions.index')); ?>" class="btn btn-outline-secondary">Back To Question</a>
                                </div>
                            </div>
                        </div>

                        <hr>
                        <div class="media">
                            <div class="d-flex flex-column vote-controls">
                                <a href="" title="This Question is useful" class="vote-up <?php echo e(Auth()->guest() ? 'off' : ''); ?>"
                                   onclick="event.preventDefault(); document.getElementById('up-vote-question-<?php echo e($question->id); ?>').submit();">
                                    <i class="fa fa-caret-up fa-3x"></i>
                                </a>
                                <form method="post" id='up-vote-question-<?php echo e($question->id); ?>' action="/questions/<?php echo e($question->id); ?>/vote" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="vote" value="1">
                                </form>
                                <span class="votes-count"><?php echo e($question->votes_count); ?></span>
                                <a class="vote-down <?php echo e(Auth()->guest() ? 'off' : ''); ?>" title="This Question is not useful"
                                   onclick="event.preventDefault(); document.getElementById('down-vote-question-<?php echo e($question->id); ?>').submit();">
                                    <i class="fa fa-caret-down fa-3x"></i>
                                </a>
                                <form method="post" id='down-vote-question-<?php echo e($question->id); ?>' action="/questions/<?php echo e($question->id); ?>/vote" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="vote" value="-1">
                                </form>
                                <a href="click (click again undo)" class="favorite mt-2 <?php echo e(Auth::guest() ? 'off': ($question->is_favorited ? 'favorited':'')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('favorite-question-<?php echo e($question->id); ?>').submit();">
                                    <i class="fa fa-star fa-2x"></i>
                                    <span class="favorites-count"><?php echo e($question->favorites_count); ?></span></a>
                                <form method="post" id='favorite-question-<?php echo e($question->id); ?>' action="/questions/<?php echo e($question->id); ?>/favorites" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php if($question->is_favorited): ?>
                                        <?php echo method_field('DELETE'); ?>
                                    <?php endif; ?>
                                </form>
                            </div>
                            <div class="media-body">
                                <?php echo $question->body; ?>

                                <div class="float-right">
                                    <span class="text-muted">Answered <?php echo e($question->created_date); ?></span>
                                    <div class="media mt-2">
                                        <a href="<?php echo e($question->user->url); ?>" class="pr-2">
                                            <img src="<?php echo e($question->user->avatar); ?>" alt="">
                                        </a>
                                        <div class="media-body mt-1">
                                            <a href="<?php echo e($question->user->url); ?>"><?php echo e($question->user->name); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('answers._index',['answers'=>$question->answers,'answerCount'=>$question->answer_count], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('answers._create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-vue\resources\views/questions/show.blade.php ENDPATH**/ ?>